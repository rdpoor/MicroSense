#include "profiling.h"

#ifdef PROFILING  // whole file

// configure pin as an output with totem pole drive
void profiling_init(PORT_t *port, uint8_t pin) {
	volatile uint8_t *port_pin_ctrl = (volatile uint8_t *)(&port->PIN0CTRL) + pin;
	*port_pin_ctrl &= PORT_OPC_TOTEM_gc;

  port->DIRSET = 1 << pin;
  port->OUTCLR = 1 << pin;
}

void profiling_set(PORT_t *port, uint8_t pin) {
  port->OUTSET = 1 << pin;
}

void profiling_clr(PORT_t *port, uint8_t pin) {
  port->OUTCLR = 1 << pin;
}

void profiling_tgl(PORT_t *port, uint8_t pin) {
  port->OUTTGL = 1 << pin;
}


#endif
